<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index() {

        $data['users'] = User::paginate(2);
        return view('users.user', $data);
    }

    public function create() {
        return view('users.create');
    }

    public function store(Request $request) {
        // return $request;

        $request->validate([
            'name' => 'required|string|regex:/^[a-zA-Z\s-]+$/',
            'email' => 'required|email|unique:users,email',
            'age' => 'required|integer',
            'gender' => 'required',
            'dob' => 'required',
            'city' => 'required',
        ]);

        $is_store = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'age' => $request->age,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'city' => $request->city,
        ]);

        if($is_store) {
            return redirect()->route('create')->with('success', 'User has been created !');
        }
        else {
            return redirect()->back()->with('error', 'Something wrong, Try again !');
        }
    }

    public function edit(Request $request, $id) {

        $data['user'] = User::where('id', '=', $id)->first();
        return view('users.edit', $data);
    }

    public function update(Request $request, $id) {
        // return $request;

        $is_update = User::where('id', $id)->update([
            'name' => $request->name,
            'age' => $request->age,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'city' => $request->city,
        ]);

        if($is_update) {
            return redirect()->route('user')->with('success', 'User has been updated !');
        }
        else {
            return redirect()->back()->with('error', 'Something wrong, Try again !');
        }
        
    }

    public function delete($id) {
        $is_delete = User::where('id', $id)->delete();

        if($is_delete) {
            return redirect()->route('user')->with('success', 'User has been delete !');
        }
        else {
            return redirect()->back()->with('error', 'Something wrong, Try again !');
        }
    }
}
